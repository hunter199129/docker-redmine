module ActionPack
  class XmlParser
    VERSION = "2.0.1"
  end
end
