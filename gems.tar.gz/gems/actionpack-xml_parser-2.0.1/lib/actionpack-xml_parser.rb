require 'action_pack/xml_parser/railtie' if defined?(Rails::Railtie)
