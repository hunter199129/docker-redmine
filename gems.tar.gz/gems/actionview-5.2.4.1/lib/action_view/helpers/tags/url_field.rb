# frozen_string_literal: true

module ActionView
  module Helpers
    module Tags # :nodoc:
      class UrlField < TextField # :nodoc:
      end
    end
  end
end
