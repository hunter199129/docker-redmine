FactoryBot.define do
  factory :enabled_module do
    project_id { 1 }
    name { 'issue_templates' }
  end
end
